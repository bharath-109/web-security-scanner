import { SecurityScanner } from './components/SecurityScanner';

function App() {
  return <SecurityScanner />;
}

export default App;
