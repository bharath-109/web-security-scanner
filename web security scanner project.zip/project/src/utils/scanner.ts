import { SecurityCheckResult, ScanResult } from '../types';

export async function performSecurityScan(url: string): Promise<ScanResult> {
  const checks: SecurityCheckResult[] = [];

  try {
    const urlObj = new URL(url);

    checks.push({
      check: 'HTTPS Protocol',
      status: urlObj.protocol === 'https:' ? 'pass' : 'fail',
      message: urlObj.protocol === 'https:'
        ? 'Site uses secure HTTPS protocol'
        : 'Site uses insecure HTTP protocol - data transmitted is not encrypted',
      details: `Protocol: ${urlObj.protocol}`,
    });

    checks.push({
      check: 'URL Structure',
      status: 'pass',
      message: 'URL structure is valid',
      details: `Host: ${urlObj.hostname}, Path: ${urlObj.pathname}`,
    });

    const hasStandardPort = urlObj.port === '' || urlObj.port === '80' || urlObj.port === '443';
    checks.push({
      check: 'Port Configuration',
      status: hasStandardPort ? 'pass' : 'warning',
      message: hasStandardPort
        ? 'Using standard port'
        : 'Using non-standard port',
      details: urlObj.port ? `Port: ${urlObj.port}` : 'Standard port',
    });

    try {
      const response = await fetch(`https://dns.google/resolve?name=${urlObj.hostname}&type=A`);
      const dnsData = await response.json();

      checks.push({
        check: 'DNS Resolution',
        status: dnsData.Status === 0 ? 'pass' : 'fail',
        message: dnsData.Status === 0
          ? 'Domain resolves correctly'
          : 'Domain does not resolve',
        details: dnsData.Answer ? `IP: ${dnsData.Answer[0]?.data}` : undefined,
      });
    } catch {
      checks.push({
        check: 'DNS Resolution',
        status: 'warning',
        message: 'Could not verify DNS resolution',
      });
    }

    const commonVulnerablePaths = [
      '/.git',
      '/.env',
      '/admin',
      '/phpmyadmin',
      '/wp-admin',
      '/config',
      '/.aws',
      '/backup',
    ];

    checks.push({
      check: 'Common Vulnerable Paths',
      status: 'info',
      message: 'Check for common vulnerable paths and exposed directories',
      details: `Testing: ${commonVulnerablePaths.join(', ')}`,
    });

    const suspiciousPatterns = [
      { pattern: /\.(php|asp|jsp)$/i, name: 'Legacy scripting extensions' },
      { pattern: /[<>'"]/g, name: 'Special characters in URL' },
      { pattern: /\.\./g, name: 'Path traversal patterns' },
    ];

    suspiciousPatterns.forEach(({ pattern, name }) => {
      const hasSuspicious = pattern.test(url);
      checks.push({
        check: `Suspicious Pattern: ${name}`,
        status: hasSuspicious ? 'warning' : 'pass',
        message: hasSuspicious
          ? `URL contains ${name}`
          : `No ${name} detected`,
      });
    });

    if (urlObj.username || urlObj.password) {
      checks.push({
        check: 'Credentials in URL',
        status: 'fail',
        message: 'URL contains embedded credentials - major security risk',
        details: 'Never include credentials in URLs',
      });
    } else {
      checks.push({
        check: 'Credentials in URL',
        status: 'pass',
        message: 'No credentials embedded in URL',
      });
    }

    checks.push({
      check: 'URL Length',
      status: url.length > 2048 ? 'warning' : 'pass',
      message: url.length > 2048
        ? 'URL is extremely long - may cause compatibility issues'
        : 'URL length is within normal range',
      details: `Length: ${url.length} characters`,
    });

    const passCount = checks.filter(c => c.status === 'pass').length;
    const score = Math.round((passCount / checks.length) * 100);

    return {
      url,
      timestamp: new Date().toISOString(),
      checks,
      score,
    };

  } catch (error) {
    throw new Error(`Failed to scan URL: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
