import { CheckCircle, XCircle, AlertTriangle, Info, TrendingUp } from 'lucide-react';
import { ScanResult } from '../types';

interface ScanResultsProps {
  result: ScanResult;
}

export function ScanResults({ result }: ScanResultsProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'fail':
        return <XCircle className="w-5 h-5 text-red-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      default:
        return <Info className="w-5 h-5 text-blue-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'border-green-700 bg-green-900/20';
      case 'fail':
        return 'border-red-700 bg-red-900/20';
      case 'warning':
        return 'border-yellow-700 bg-yellow-900/20';
      default:
        return 'border-blue-700 bg-blue-900/20';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Good';
    if (score >= 60) return 'Fair';
    return 'Poor';
  };

  const passCount = result.checks.filter(c => c.status === 'pass').length;
  const failCount = result.checks.filter(c => c.status === 'fail').length;
  const warningCount = result.checks.filter(c => c.status === 'warning').length;

  return (
    <div className="space-y-6">
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-2xl border border-slate-700 p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Scan Results</h2>
            <p className="text-slate-400 text-sm break-all">{result.url}</p>
            <p className="text-slate-500 text-xs mt-1">
              Scanned at {new Date(result.timestamp).toLocaleString()}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-700">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-sm font-medium">Security Score</span>
              <TrendingUp className={`w-5 h-5 ${getScoreColor(result.score)}`} />
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-4xl font-bold ${getScoreColor(result.score)}`}>
                {result.score}
              </span>
              <span className="text-slate-500 text-lg">/100</span>
            </div>
            <p className={`text-sm mt-2 font-medium ${getScoreColor(result.score)}`}>
              {getScoreLabel(result.score)}
            </p>
          </div>

          <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-700">
            <div className="text-slate-400 text-sm font-medium mb-3">Check Summary</div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  Passed
                </span>
                <span className="text-white font-semibold">{passCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  Warnings
                </span>
                <span className="text-white font-semibold">{warningCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm flex items-center gap-2">
                  <XCircle className="w-4 h-4 text-red-400" />
                  Failed
                </span>
                <span className="text-white font-semibold">{failCount}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-white mb-4">Detailed Checks</h3>
          {result.checks.map((check, index) => (
            <div
              key={index}
              className={`border rounded-lg p-4 transition-all hover:shadow-md ${getStatusColor(check.status)}`}
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 mt-0.5">
                  {getStatusIcon(check.status)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h4 className="text-white font-semibold text-sm">
                      {check.check}
                    </h4>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full whitespace-nowrap ${
                      check.status === 'pass' ? 'bg-green-900/50 text-green-300' :
                      check.status === 'fail' ? 'bg-red-900/50 text-red-300' :
                      check.status === 'warning' ? 'bg-yellow-900/50 text-yellow-300' :
                      'bg-blue-900/50 text-blue-300'
                    }`}>
                      {check.status.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-slate-300 text-sm mb-1">
                    {check.message}
                  </p>
                  {check.details && (
                    <p className="text-slate-500 text-xs font-mono">
                      {check.details}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
