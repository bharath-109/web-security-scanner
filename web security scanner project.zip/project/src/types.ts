export interface SecurityCheckResult {
  check: string;
  status: 'pass' | 'fail' | 'warning' | 'info';
  message: string;
  details?: string;
}

export interface ScanResult {
  url: string;
  timestamp: string;
  checks: SecurityCheckResult[];
  score: number;
}

export interface ScanHistory {
  id: string;
  result: ScanResult;
}
